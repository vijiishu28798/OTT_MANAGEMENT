import express, { Application } from 'express';
import userRouter from './src/api/v1/controller/user.controller';
import movieRouter from './src/api/v1/controller/movie.controller';

import  {connectDB}  from './src/api/v1/db/config'

const app:Application = express();

app.use(express.json());

app.use('/users', userRouter);
app.use('/movies', movieRouter);

const PORT = process.env.APP_PORT || 3000;
app.listen(PORT, () => {
 console.log(`Server is up and running on port ${PORT}`);
    connectDB();

});

export default app; 




