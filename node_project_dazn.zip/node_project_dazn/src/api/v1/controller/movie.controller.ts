import express, { Request, Response, Router } from 'express';
import MovieModel from '../models/movies.model';
import verifyJwt,{ JwtRequest  } from '../middleware/auth';
import { checkRole  } from '../middleware/roles';
const movieRouter: Router = express.Router();

movieRouter.get('/getAllMovies',verifyJwt, async (req: JwtRequest, res: Response) => {
    const movies = await MovieModel.find();
if(movies.length===0){
  return res.json({statusCode:404,message:"no data found"})
} 
return res.json({statusCode:200,message:"success",data:movies})


});

movieRouter.get('/searchMovies', verifyJwt, async (req: JwtRequest, res: Response) => {

   const { q } = req.query;
   console.log("yes"+q);

    const movies = await MovieModel.find({
      $or: [
        { title: { $regex: new RegExp(q as string, 'i') } },
        { genre: { $regex: new RegExp(q as string, 'i') } },
      ],
    });
    if(movies.length===0){
      return res.json({statusCode:404,message:"no data found"})
    } 
    return res.json({statusCode:200,message:"success",data:movies})
});

movieRouter.post('/addMovie', verifyJwt, checkRole(['admin']), async (req: JwtRequest, res: Response) => {
  const { title, genre, rating, streamingLink } = req.body;
    const newMovie = await MovieModel.create({ title, genre, rating, streamingLink });
    res.status(201).json(newMovie);
 
});

movieRouter.put('/updateMovie/:id', verifyJwt, checkRole(['admin']), async (req: JwtRequest, res: Response) => {

   const {id } = req.params;
   const { title, genre, rating, streamingLink } = req.body;


 
    const movie = await MovieModel.findByIdAndUpdate(
      id,
      { title, genre, rating, streamingLink },
    );

    if(!movie){
      return res.json({statusCode:404,message:"data not found"})
     }
    return res.json({statusCode:200,message:"movie updated successfully"})

 
});

movieRouter.delete('/deleteMovie/:id', verifyJwt, checkRole(['admin']), async (req: JwtRequest, res: Response) => {
  const { id } = req.params;
  
  
    const movie = await MovieModel.findByIdAndDelete(id);
    if(!movie){
      return res.json({statusCode:404,message:"movie not found"})
    }
    return res.json({statusCode:200,message:"movie deleted successfully"})
 
});


export default movieRouter;