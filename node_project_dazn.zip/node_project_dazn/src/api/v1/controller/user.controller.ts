import express, { Request, Response, Router } from 'express';
import jwt from 'jsonwebtoken';
import users from '../models/user.model';
import verifyJwt,{ JwtRequest  } from '../middleware/auth';
import { checkRole  } from '../middleware/roles';

const userRouter: Router = express.Router();

userRouter.post('/signin', async (req: Request, res: Response) => {
 try {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) {
    return res.json({statusCode:401,message:"User does not exist"});
  }
  if (user.password !== password) {
   return res.json({statusCode:401,message:"Wrong Password"})
  }
  const token = jwt.sign({ id: user.id, type: user.type }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });
  return res.json({statusCode:200,message:"success",token:token})
} catch (error: any) {
 return res.json({statusCode:500,message:"error",error:error.message})
 }
});

userRouter.get('/admin-only', verifyJwt, checkRole(['admin']), async (req: JwtRequest, res: Response) => {
    res.status(200).json({ message: 'This can only be accessed by admins' });
   });
   
   userRouter.get('/admin-and-teachers', verifyJwt, checkRole(['admin', 'user']), async (req: JwtRequest, res: Response) => {
    res.status(200).json({ message: 'This can only be accessed by admins and teachers' });
   });
   
  


export default userRouter;