import mongoose, { ConnectOptions } from "mongoose";

const DB_URL = 'mongodb://localhost/OTT_management';

const connectDB = async (): Promise<void> => {
  try {
    const options: ConnectOptions = {
      //useNewUrlParser: true,
      //useUnifiedTopology: true,
    };

    await mongoose.connect('mongodb://localhost/OTT_management', options);
    console.log('Connected to database');
  } catch (error) {
    console.error(' Database connection error -', error);
    process.exit(1);
  }
};

export {connectDB};


