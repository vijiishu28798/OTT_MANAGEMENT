import { JwtRequest } from '../middleware/auth';
import { Response, NextFunction } from 'express';

export function checkRole(allowedRoles: ('admin' | 'user')[]) {
 return (req: JwtRequest, res: Response, next: NextFunction) => {
  const user = req.user;

  if (user && !allowedRoles.includes(user.type)) {

    
   return res.json({statusCode:403,message:`this service is only available for ${allowedRoles}` });
  }

  next();
 };
}