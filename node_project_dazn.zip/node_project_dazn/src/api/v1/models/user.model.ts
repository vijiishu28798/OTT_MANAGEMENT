export interface User {
    id: number;
    name: string;
    email: string;
    password: string;
    type: 'admin' | 'user' ;
   }
   
   const users: User[] = [
    { id: 1, name: 'Admin', email: 'admin@gmail.com', password: 'admin@123', type: 'admin' },
    { id: 2, name: 'viji', email: 'viji@gmail.com', password: 'viji@123', type: 'user' },
   ];


   export default users;