userRouter.get('/admin-only', verifyJwt, checkRole(['admin']), async (req: JwtRequest, res: Response) => {
    res.status(200).json({ message: 'This can only be accessed by admins' });
   });
   
   userRouter.get('/admin-and-teachers', verifyJwt, checkRole(['admin', 'teacher']), async (req: JwtRequest, res: Response) => {
    res.status(200).json({ message: 'This can only be accessed by admins and teachers' });
   });
   
   userRouter.get('/admin-teachers-students', verifyJwt, checkRole(['admin', 'teacher', 'student']), async (req: JwtRequest, res: Response) => {
    res.status(200).json({ message: 'This can only be accessed by admins, teachers and students' });
   });